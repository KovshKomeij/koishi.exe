#include <iostream>
#include <thread>
#include <cstdlib>
#include <Windows.h>
#include <mmsystem.h>

#pragma comment(lib, "Winmm.lib")

using namespace std;

bool running = true;
int seconds = 0;

void timelater() {
	while (true) {
		Sleep(1000);
		seconds++;
		if (!running) {
			break;
		}
	}
}

int main() {
	HWND hCons = GetConsoleWindow();

	ShowWindow(hCons, SW_HIDE);

	thread t(timelater);
	t.detach();

	LPCWSTR filePath = L"music.wav";

	PlaySound(filePath, NULL, SND_FILENAME | SND_ASYNC);

	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);

	// ��� �� ��� ������������ ChatGPT

	HBITMAP hBitmap = (HBITMAP)LoadImage(NULL, L"pic1.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

	BITMAP bm;
	GetObject(hBitmap, sizeof(BITMAP), &bm);
	int width = bm.bmWidth;
	int height = bm.bmHeight;

	HDC hdcBitmap = CreateCompatibleDC(NULL);
	HGDIOBJ hOldBitmap = SelectObject(hdcBitmap, hBitmap);

	// ������ � ��� ����� ���� ����

	while (true) {
		BitBlt(hdc, rand() % (0 - w), rand() % (0 - h), width, height, hdcBitmap, 0, 0, SRCCOPY);
		Sleep(250);

		if (seconds >= 20) {
			break;
		}
	}

	while (true) {
		BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, PATINVERT);
		StretchBlt(hdc, 50, 50, w - 100, h - 100, hdc, 0, 0, w, h, SRCCOPY);
		Sleep(100);

		if (seconds >= 32) {
			break;
		}
	}

	while (true) {
		BitBlt(hdc, rand() % (0 - w), rand() % (0 - h), width, height, hdcBitmap, 0, 0, SRCCOPY);
		Sleep(250);

		if (seconds >= 62) {
			break;
		}
	}

	while (true) {
		BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, PATINVERT);
		StretchBlt(hdc, 50, 50, w - 100, h - 100, hdc, 0, 0, w, h, SRCCOPY);
		Sleep(100);

		if (seconds >= 74) {
			break;
		}
	}

	while (true) {
		BitBlt(hdc, rand() % (0 - w), rand() % (0 - h), width, height, hdcBitmap, 0, 0, SRCCOPY);
		Sleep(250);

		if (seconds >= 97) {
			running = false;
			break;
		}
	}

	return 0;
}